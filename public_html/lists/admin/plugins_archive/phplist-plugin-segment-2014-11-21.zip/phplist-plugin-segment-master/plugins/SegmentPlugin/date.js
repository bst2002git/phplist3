<script type="text/javascript">
$(function() {
    $( ".datepicker" ).datepicker({ dateFormat: "d M yy" });
});
</script>
