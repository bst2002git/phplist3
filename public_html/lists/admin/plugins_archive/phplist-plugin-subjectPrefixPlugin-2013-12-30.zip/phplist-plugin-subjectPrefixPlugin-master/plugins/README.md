phplist-plugin-subjectPrefixPlugin
===================================

A plugin to allow a prefix to be added to the subject line of list messages. The prefix does not need to be the list name. It can be whatever prefix the list admin wants.

For more info see http://resources.phplist.com/plugins/subjectPrefixPlugin
