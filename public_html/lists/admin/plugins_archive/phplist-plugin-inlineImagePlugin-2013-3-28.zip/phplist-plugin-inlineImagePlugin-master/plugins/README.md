phplist-plugin-inlineImagePlugin
===================================

A plugin to allow images to be attached and embedded in phplist messages.

For more info see http://resources.phplist.com/plugins/inlineimage