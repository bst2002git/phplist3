phplist-plugin-listNamePrefixPlugin
===================================

A plugin to prefix list messages with the list name 

For more info see http://resources.phplist.com/plugins/listnameprefix
