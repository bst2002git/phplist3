<html>
<head></head>
    <body>
        <table width="100%" border="0">
            <tr>
                <td width="100%">
                    <img src="http://www.phplist.com/images/phplist-logo.png" />
                    <span style="float:right;font-size:12px"></span>
                </td>
            </tr>
        </table>
    </body>
</html>
