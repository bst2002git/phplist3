<html>
    <head></head>
    <body>
        <table width="100%" border="0">
            <tr>
                <td width="100%" style="text-align:right; font-size:9px;"><?php echo strftime("%c");?></td>
            </tr>
        </table>
    </body>
</html>
