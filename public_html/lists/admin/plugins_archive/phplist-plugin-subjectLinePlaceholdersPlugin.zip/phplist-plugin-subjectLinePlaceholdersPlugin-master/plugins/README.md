phplist-plugin-subjectLinePlaceholdersPlugin
===================================

A plugin to allow placeholders for user attributes in the subject lines of messages.

For more info see http://resources.phplist.com/plugins/subjectlineplaceholder.
