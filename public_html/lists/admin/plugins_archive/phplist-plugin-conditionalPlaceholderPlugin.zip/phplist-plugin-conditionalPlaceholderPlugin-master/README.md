phplist-plugin-conditionalPlaceholdersPlugin
===================================

A plugin to allow conditional placeholders in phplist messages, including in the subject line.
If there is no value for certain text containing the placeholder, alternate text is inserted into the message.

The clumsy areas of code have been replaced in this release. This version allows you to configure the syntax to a large extent.

For more info see http://resources.phplist.com/plugins/conditionalplaceholder
